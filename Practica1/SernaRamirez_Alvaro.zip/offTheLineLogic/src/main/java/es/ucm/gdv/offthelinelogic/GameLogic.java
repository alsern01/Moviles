package es.ucm.gdv.offthelinelogic;

public class GameLogic {
}