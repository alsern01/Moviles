package es.ucm.gdv.desktopgame;

import es.ucm.gdv.engine.desktopengine.*;
import es.ucm.gdv.offthelinelogic.*;

public class MainClass {
    public static void main(String[] args) {

    }
}