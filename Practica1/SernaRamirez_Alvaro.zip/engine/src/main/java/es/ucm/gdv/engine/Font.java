package es.ucm.gdv.engine;

public interface Font {

}
